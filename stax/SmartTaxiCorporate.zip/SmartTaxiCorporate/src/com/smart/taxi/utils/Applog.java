package com.smart.taxi.utils;

import android.util.Log;

public class Applog {
	public static void Debug(String msg){
		Log.d("Umair", msg);
	}

	public static void Error(String msg) {
		Log.e("Umair", msg);
	} 
}
