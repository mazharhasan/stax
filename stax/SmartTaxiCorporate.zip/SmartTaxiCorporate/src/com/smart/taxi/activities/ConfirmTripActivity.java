package com.smart.taxi.activities;

import android.os.Bundle;

import com.smarttaxi.client.R;

public class ConfirmTripActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_confirm_trip);
	}


}
