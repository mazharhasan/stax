package com.smart.taxi.activities;

import java.util.List;

import android.app.ListFragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.smart.taxi.components.renderers.CardRenderer;
import com.smart.taxi.entities.Card;
import com.smarttaxi.client.R;

public class PaymentOptionsFragment extends ListFragment
{
	public static String TAG = "PaymentOptions";
	View rootView;
	
	public PaymentOptionsFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = inflater.inflate(R.layout.fragment_list_cards, container, false);
		loadCards();
		return rootView;
	}

	private void loadCards() {
		if(SplashActivity.isLoggedIn() && SplashActivity.loggedInUser.hasCards())
		{
			ListAdapter cards = new CardsAdapter(getActivity(), SplashActivity.loggedInUser.getUserCards());
			setListAdapter(cards);
		}else{
			
		}
		
	}
	
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		//TripHistoryRenderer renderer = (TripHistoryRenderer) getListAdapter().getItem(position);
		//Log.e("Click message", getListAdapter().getItem(position).toString());
        //startActivity(new Intent(this, demo.activityClass));
    }
	
	private static class CardsAdapter extends ArrayAdapter<Card> {

        /**
         * @param demos An array containing the details of the demos to be displayed.
         */
        public CardsAdapter(Context context, List<Card> cards) {
        	super(context, R.id.txtPassengerName);
        	this.addAll(cards);
            //super(context, R.layout.feature, R.id.title, labels);
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
        	CardRenderer renderer;
            if (convertView instanceof CardRenderer) {
            	renderer = (CardRenderer) convertView;
            } else {
            	renderer = new CardRenderer(getContext());
            }
            Card card= getItem(position);
            renderer.setData(card);
            

            return renderer;
        }
        
    }
}

