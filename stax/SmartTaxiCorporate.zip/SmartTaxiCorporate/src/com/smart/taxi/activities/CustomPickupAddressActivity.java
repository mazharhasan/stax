package com.smart.taxi.activities;

import android.os.Bundle;

import com.smarttaxi.client.R;

public class CustomPickupAddressActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_custom_pickup_address);
	}

}
