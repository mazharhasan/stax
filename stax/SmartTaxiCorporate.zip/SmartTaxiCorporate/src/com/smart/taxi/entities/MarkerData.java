package com.smart.taxi.entities;


public class MarkerData {

	public MarkerData() {
		// TODO Auto-generated constructor stub
	}

}
