package com.smart.taxi.interfaces;

public interface ICustomFontTextField {

	public String getFontName();

	public void setFontName(String fontName);

}
