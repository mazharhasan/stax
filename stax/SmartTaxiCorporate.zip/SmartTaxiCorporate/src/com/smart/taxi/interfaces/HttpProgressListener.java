package com.smart.taxi.interfaces;

public interface HttpProgressListener {
	
	public void onProgress(Object value);

}
